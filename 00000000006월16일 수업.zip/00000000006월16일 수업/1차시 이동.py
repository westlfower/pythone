import tkinter as tk

#변수들
w=1200  #캔버스 너비
h=600   #캔버스 높이
step=60    #이동 칸 및 격자 가로 세로 길이

#함수들
#좌표를 격자에 맞추어  변환 함수
def f(x,y):
    return (x*step,600+(-y)*step)


'''
기본틀
win= tk.Tk()
can=tk.Canvas(win,width=w, height=h, bg="white")
can.pack()
win.mainloop()
'''

win= tk.Tk()
can=tk.Canvas(win,width=w, height=h, bg="white")
can.pack()
#win.mainloop()
