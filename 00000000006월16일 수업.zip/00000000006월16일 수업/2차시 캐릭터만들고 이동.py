import tkinter as tk

#변수들
w=1200  #캔버스 너비
h=600   #캔버스 높이
step=60    #이동 칸 및 격자 가로 세로 길이
grid_color=["white","black"]

map_data=[[0,0,1,0,0,1,1,1],[1,0,1,1,0,0,1,0],[1,0,1,0,0,0,0,0],[1,0,0,0,0,0,1,0],[1,0,0,1,0,1,0,0]] #8*5

c_x=0 #캐릭터 위치
c_y=0
# 키조작 변수 on, off 확인
key=""

#함수들
#좌표를 격자에 맞추어  변환 함수
def f(x,y):
    return (x*step,600+(-y)*step)

def draw_screen():
    #격자 그리기
    for y in range(0,5,1):
        for x in range(0,8,1):
            can.create_rectangle(*f(x,y),*f(x+1,y+1),fill=grid_color[map_data[y][x]],tag="BG")
    #(추가) 캐릭터 그리기
    can.create_rectangle(*f(c_x,c_y),*f(c_x+1,c_y+1),fill="blue",tag="BG")

#버튼 조작
def key_down(event):
    global key
    key = event.keysym
def key_up(event):
    global key
    key=""

#버튼 조작 움직임 함수
def move():
    global c_x, c_y
    if key=="Left":
        c_x=c_x-1
    elif key=="Right":
        c_x=c_x+1
    elif key=="Up":
        c_y=c_y+1  
    elif key=="Down":
        c_y=c_y-1
#변화 반영
def update():
    move()
    can.delete("BG")  # 이전에 그린 오브젝트 삭제
    draw_screen()
    win.after(100, update)  # 0.1초마다 update 호출
'''
기본틀
win= tk.Tk()
can=tk.Canvas(win,width=w, height=h, bg="white")
can.pack()
win.mainloop()
'''

win= tk.Tk()
can=tk.Canvas(win,width=w, height=h, bg="white")
can.pack()

#버튼 조작

win.bind("<KeyPress>",key_down)
win.bind("<KeyRelease>",key_up)
update()



win.mainloop()
