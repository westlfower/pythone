import tkinter as tk

# 변수들
w = 1200  # 캔버스 너비
h = 600   # 캐버스 높이
step = 60    # 이동 칸 및 격자 가로 세로 길이
grid_color = ["white", "black"]  # 0:흰색, 1:검정색

map_data = [
    [0,0,1,0,0,1,1,1],
    [1,0,1,1,0,0,1,0],
    [1,0,1,0,0,0,0,0],
    [1,0,0,0,0,0,1,0],
    [1,0,0,1,0,1,0,0]
]  # 8*5

c_x = 0  # 캐릭터 위치 (시작점)
c_y = 0
key = ""  # 키 조작 변수

# 좌표 변환 함수
def f(x, y):
    return (x * step, h + (-y) * step)

def draw_screen():
    can.delete("BG")  # 이전에 그린 오브젝트 삭제
    # 격자 그리기
    for y in range(len(map_data)):
        for x in range(len(map_data[0])):
            can.create_rectangle(*f(x, y), *f(x+1, y+1),
                                 fill=grid_color[map_data[y][x]],
                                 tag="BG")
    # 캐릭터 그리기
    can.create_rectangle(*f(c_x, c_y), *f(c_x+1, c_y+1),
                         fill="blue", tag="BG")

def key_down(event):
    global key
    key = event.keysym

def move():
    global c_x, c_y
    new_x, new_y = c_x, c_y
    if key == "Left":
        new_x = max(0, c_x - 1)
    elif key == "Right":
        new_x = min(len(map_data[0])-1, c_x + 1)
    elif key == "Up":
        new_y = min(len(map_data)-1, c_y + 1)
    elif key == "Down":
        new_y = max(0, c_y - 1)
    # 이동하려는 칸이 흰색(0)인 경우에만 이동
    if 0 <= new_x < len(map_data[0]) and 0 <= new_y < len(map_data):
        if map_data[new_y][new_x] == 0:
            c_x, c_y = new_x, new_y

def update():
    move()
    draw_screen()
    win.after(100, update)  # 0.1초마다 update 호출

win = tk.Tk()
can = tk.Canvas(win, width=w, height=h, bg="white")
can.pack()
win.bind("<KeyPress>", key_down)
update()  # 반복 호출 시작
win.mainloop()
