import tkinter as tk

#변수들
w=1200  #캔버스 너비
h=600   #캔버스 높이
step=60    #이동 칸 및 격자 가로 세로 길이
grid_color=["white","black"]

map_data=[[0,0,1,0,0,1,1,1],[1,0,1,1,0,0,1,0],[1,0,1,0,0,0,0,0],[1,0,0,0,0,0,1,0],[1,0,0,1,0,1,0,0]] #8*5


#함수들
#좌표를 격자에 맞추어  변환 함수
def f(x,y):
    return (x*step,600+(-y)*step)

def draw_screen():
    #격자 그리기
    for y in range(0,5,1):
        for x in range(0,8,1):
            can.create_rectangle(*f(x,y),*f(x+1,y+1),fill=grid_color[map_data[y][x]])
    
'''
기본틀
win= tk.Tk()
can=tk.Canvas(win,width=w, height=h, bg="white")
can.pack()
win.mainloop()
'''

win= tk.Tk()
can=tk.Canvas(win,width=w, height=h, bg="white")
can.pack()

draw_screen()




win.mainloop()
